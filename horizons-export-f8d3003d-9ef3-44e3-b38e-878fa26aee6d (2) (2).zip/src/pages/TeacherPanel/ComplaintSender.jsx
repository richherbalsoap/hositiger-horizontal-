
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Send, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAppContext } from '@/hooks/useAppContext';
import { STANDARDS, SECTIONS } from '@/lib/utils';

const ComplaintSender = () => {
  const [standard, setStandard] = useState('');
  const [section, setSection] = useState('');
  const [selectedStudent, setSelectedStudent] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { addComplaint, students } = useAppContext();

  const filteredStudents = students.filter(s => s.standard === standard && s.class_section === section);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!standard || !section || !selectedStudent || !message) {
      toast({ title: "Validation Error", description: "Please fill all required fields", variant: "destructive" });
      return;
    }

    setLoading(true);
    await addComplaint({ student_id: selectedStudent, standard, class_section: section, message });

    toast({ title: "Complaint Sent Successfully", description: "Complaint logged and saved to system." });
    setStandard('');
    setSection('');
    setSelectedStudent('');
    setMessage('');
    setLoading(false);
  };

  return (
    <>
      <Helmet><title>Send Complaint - SchoolHub</title></Helmet>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl mx-auto py-8">
        <h1 className="text-4xl font-extrabold text-[#1A1A1A] mb-8 text-center tracking-tight">
          Log a Complaint
        </h1>

        <form onSubmit={handleSubmit} className="bg-white/40 backdrop-blur-xl rounded-3xl p-8 shadow-xl border border-white/50 space-y-8">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Standard *</label>
              <select
                value={standard}
                onChange={(e) => { setStandard(e.target.value); setSelectedStudent(''); }}
                className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all appearance-none"
                required
              >
                <option value="" className="text-gray-400">Select Standard</option>
                {STANDARDS.map(std => <option key={std} value={std} className="text-[#1A1A1A]">{std}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Class *</label>
              <select
                value={section}
                onChange={(e) => { setSection(e.target.value); setSelectedStudent(''); }}
                className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all appearance-none"
                required
              >
                <option value="" className="text-gray-400">Select Class</option>
                {SECTIONS.map(sec => <option key={sec} value={sec} className="text-[#1A1A1A]">{sec}</option>)}
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Student Name *</label>
            <select
              value={selectedStudent}
              onChange={(e) => setSelectedStudent(e.target.value)}
              className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all appearance-none disabled:opacity-50"
              required
              disabled={!standard || !section}
            >
              <option value="" className="text-gray-400">Select a student</option>
              {filteredStudents.map(student => <option key={student.id} value={student.id} className="text-[#1A1A1A]">{student.name}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Complaint Details *</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl placeholder-[#1A1A1A]/30 text-[#1A1A1A] h-40 resize-none focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all"
              placeholder="Describe the issue clearly..."
              required
            />
          </div>

          <Button type="submit" disabled={loading} className="w-full bg-red-600 hover:bg-red-700 text-white py-4 rounded-xl font-bold shadow-lg transition-all h-auto">
            <AlertTriangle className="w-5 h-5 mr-2" />
            {loading ? 'Submitting...' : 'Register Complaint'}
          </Button>
        </form>
      </motion.div>
    </>
  );
};

export default ComplaintSender;
