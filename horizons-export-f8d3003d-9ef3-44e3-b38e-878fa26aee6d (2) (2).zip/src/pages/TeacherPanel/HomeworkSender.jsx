
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Upload, Send, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAppContext } from '@/hooks/useAppContext';
import { useAuth } from '@/hooks/useAuth';
import { STANDARDS, SECTIONS } from '@/lib/utils';

const HomeworkSender = () => {
  const [standard, setStandard] = useState('');
  const [section, setSection] = useState('');
  const [fileBase64, setFileBase64] = useState('');
  const [fileName, setFileName] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { addHomework } = useAppContext();
  const { user } = useAuth();

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setFileBase64(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!standard || !section || !notes) {
      toast({ title: "Error", description: "Please fill required fields", variant: "destructive" });
      return;
    }

    setLoading(true);
    
    await addHomework({
      standard,
      class_section: section,
      notes,
      file_url: fileBase64,
      teacher_id: user?.id
    });

    toast({ title: "Success", description: "Homework sent successfully!" });
    setStandard('');
    setSection('');
    setNotes('');
    setFileBase64('');
    setFileName('');
    setLoading(false);
  };

  return (
    <>
      <Helmet><title>Send Homework - SchoolHub</title></Helmet>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl mx-auto py-8">
        <h1 className="text-4xl font-extrabold text-[#1A1A1A] mb-8 text-center tracking-tight">
          Homework Sender
        </h1>
        
        <form onSubmit={handleSubmit} className="bg-white/40 backdrop-blur-xl rounded-3xl p-8 shadow-xl border border-white/50 space-y-8">
          
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Standard</label>
              <select
                value={standard}
                onChange={(e) => setStandard(e.target.value)}
                className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all appearance-none"
                required
              >
                <option value="" className="text-gray-400">Select Standard</option>
                {STANDARDS.map(std => (
                  <option key={std} value={std} className="text-[#1A1A1A]">{std}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Class Section</label>
              <select
                value={section}
                onChange={(e) => setSection(e.target.value)}
                className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all appearance-none"
                required
              >
                <option value="" className="text-gray-400">Select Section</option>
                {SECTIONS.map(sec => (
                  <option key={sec} value={sec} className="text-[#1A1A1A]">{sec}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Attachment</label>
            <div className="relative border-2 border-dashed border-[#1A1A1A]/10 rounded-2xl p-8 text-center hover:border-[#1A1A1A]/30 hover:bg-white/40 transition-all group cursor-pointer bg-white/20">
              <input type="file" onChange={handleFileChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/*,.pdf" />
              <div className="flex flex-col items-center justify-center gap-3">
                 <div className="w-12 h-12 rounded-full bg-[#1A1A1A]/5 flex items-center justify-center group-hover:bg-[#1A1A1A]/10 transition-colors">
                    <Upload className="w-6 h-6 text-[#1A1A1A]/60 group-hover:text-[#1A1A1A]" />
                 </div>
                 <p className="text-[#1A1A1A]/70 text-sm font-medium">{fileName || "Drop file here or click to upload"}</p>
                 <span className="text-xs text-[#1A1A1A]/40">Supports PDF, PNG, JPG</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Instructions</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl h-32 resize-none placeholder-[#1A1A1A]/30 text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all"
              placeholder="Write detailed instructions for the students..."
              required
            />
          </div>

          <Button type="submit" disabled={loading} className="w-full bg-[#1A1A1A] hover:bg-[#1A1A1A]/90 text-white py-4 rounded-xl font-bold shadow-lg transition-all h-auto">
            {loading ? 'Sending...' : 'Distribute Homework'}
          </Button>
        </form>
      </motion.div>
    </>
  );
};

export default HomeworkSender;
