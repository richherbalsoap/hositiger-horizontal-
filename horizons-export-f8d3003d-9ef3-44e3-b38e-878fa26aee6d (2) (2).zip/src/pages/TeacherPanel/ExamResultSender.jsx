
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Upload, Send, Award, Plus, Trash2, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAppContext } from '@/hooks/useAppContext';
import { STANDARDS, SECTIONS, SUBJECTS as DEFAULT_SUBJECTS } from '@/lib/utils';

const ExamResultSender = () => {
  const [standard, setStandard] = useState('');
  const [section, setSection] = useState('');
  const [selectedStudent, setSelectedStudent] = useState('');
  const [subject, setSubject] = useState('');
  const [marks, setMarks] = useState('');
  const [totalMarks, setTotalMarks] = useState('100');
  const [resultImage, setResultImage] = useState('');
  const [fileName, setFileName] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Custom Subject States
  const [allSubjects, setAllSubjects] = useState(DEFAULT_SUBJECTS);
  const [customSubjectName, setCustomSubjectName] = useState('');
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [customSubjectsList, setCustomSubjectsList] = useState([]);

  const { toast } = useToast();
  const { students, addResult } = useAppContext();

  const filteredStudents = students.filter(s => s.standard === standard && s.class_section === section);

  // Load custom subjects from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('customSubjects');
    if (saved) {
      const parsed = JSON.parse(saved);
      setCustomSubjectsList(parsed);
      setAllSubjects([...DEFAULT_SUBJECTS, ...parsed]);
    }
  }, []);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => setResultImage(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSubjectChange = (e) => {
    const value = e.target.value;
    if (value === 'ADD_CUSTOM') {
      setShowCustomInput(true);
      setSubject('');
    } else {
      setShowCustomInput(false);
      setSubject(value);
    }
  };

  const handleAddCustomSubject = () => {
    if (!customSubjectName.trim()) return;
    
    if (allSubjects.includes(customSubjectName)) {
      toast({ title: "Error", description: "Subject already exists", variant: "destructive" });
      return;
    }

    const newCustomList = [...customSubjectsList, customSubjectName];
    setCustomSubjectsList(newCustomList);
    setAllSubjects([...DEFAULT_SUBJECTS, ...newCustomList]);
    setSubject(customSubjectName);
    setCustomSubjectName('');
    setShowCustomInput(false);
    
    // Persist
    localStorage.setItem('customSubjects', JSON.stringify(newCustomList));
    toast({ title: "Subject Added", description: `Added ${customSubjectName} to subjects list` });
  };

  const handleDeleteCustomSubject = (subjToDelete) => {
    const newCustomList = customSubjectsList.filter(s => s !== subjToDelete);
    setCustomSubjectsList(newCustomList);
    setAllSubjects([...DEFAULT_SUBJECTS, ...newCustomList]);
    if (subject === subjToDelete) setSubject('');
    localStorage.setItem('customSubjects', JSON.stringify(newCustomList));
    toast({ title: "Deleted", description: "Subject removed from list." });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!standard || !section || !selectedStudent || !subject || !marks) {
      toast({ title: "Error", description: "Fill all required fields", variant: "destructive" });
      return;
    }

    setLoading(true);

    await addResult({
      student_id: selectedStudent,
      standard,
      class_section: section,
      subject,
      marks: parseFloat(marks),
      total_marks: parseFloat(totalMarks),
      photo_url: resultImage,
    });

    toast({ title: "Success", description: "Result saved successfully" });
    setMarks('');
    setResultImage('');
    setFileName('');
    setLoading(false);
  };

  return (
    <>
      <Helmet><title>Upload Result - SchoolHub</title></Helmet>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl mx-auto py-8">
        <h1 className="text-4xl font-extrabold text-[#1A1A1A] mb-8 text-center tracking-tight">
          Publish Exam Results
        </h1>
        
        <form onSubmit={handleSubmit} className="bg-white/40 backdrop-blur-xl rounded-3xl p-8 shadow-xl border border-white/50 space-y-8">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Standard</label>
              <select value={standard} onChange={e => setStandard(e.target.value)} className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all appearance-none" required>
                <option value="" className="text-gray-400">Select Standard</option>
                {STANDARDS.map(s => <option key={s} value={s} className="text-[#1A1A1A]">{s}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Class Section</label>
              <select value={section} onChange={e => setSection(e.target.value)} className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all appearance-none" required>
                <option value="" className="text-gray-400">Select Section</option>
                {SECTIONS.map(s => <option key={s} value={s} className="text-[#1A1A1A]">{s}</option>)}
              </select>
            </div>
          </div>

          <div className="space-y-2">
             <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Student</label>
             <select value={selectedStudent} onChange={e => setSelectedStudent(e.target.value)} className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all appearance-none disabled:opacity-50" disabled={!standard || !section} required>
               <option value="" className="text-gray-400">Select Student</option>
               {filteredStudents.map(s => <option key={s.id} value={s.id} className="text-[#1A1A1A]">{s.name}</option>)}
             </select>
           </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Subject</label>
              <select 
                value={showCustomInput ? 'ADD_CUSTOM' : subject} 
                onChange={handleSubjectChange} 
                className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all appearance-none" 
                required
              >
                <option value="" className="text-gray-400">Select Subject</option>
                {allSubjects.map(s => <option key={s} value={s} className="text-[#1A1A1A]">{s}</option>)}
                <option value="ADD_CUSTOM" className="font-bold text-blue-600">+ Add Custom Subject</option>
              </select>
              
              {showCustomInput && (
                <div className="mt-2 flex gap-2">
                  <input 
                    type="text" 
                    value={customSubjectName}
                    onChange={(e) => setCustomSubjectName(e.target.value)}
                    placeholder="Enter subject name"
                    className="flex-1 px-3 py-2 bg-white border border-[#1A1A1A]/10 rounded-lg text-sm"
                  />
                  <Button type="button" onClick={handleAddCustomSubject} size="sm" className="bg-[#1A1A1A] text-white">Add</Button>
                  <Button type="button" onClick={() => setShowCustomInput(false)} size="sm" variant="ghost">Cancel</Button>
                </div>
              )}

              {/* List of Custom Subjects with Delete Option */}
              {customSubjectsList.length > 0 && !showCustomInput && (
                 <div className="mt-2">
                    <p className="text-[10px] text-[#1A1A1A]/40 uppercase font-bold mb-1">Custom Subjects:</p>
                    <div className="flex flex-wrap gap-1">
                      {customSubjectsList.map(s => (
                        <div key={s} className="flex items-center gap-1 bg-[#1A1A1A]/5 px-2 py-1 rounded text-xs text-[#1A1A1A]">
                          {s}
                          <button type="button" onClick={() => handleDeleteCustomSubject(s)} className="text-red-500 hover:text-red-700">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                 </div>
              )}
            </div>
            <div className="space-y-2">
              <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Obtained Marks</label>
              <input type="number" value={marks} onChange={e => setMarks(e.target.value)} className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] placeholder-[#1A1A1A]/30 focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all" placeholder="0" required />
            </div>
             <div className="space-y-2">
              <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Total Marks</label>
              <input type="number" value={totalMarks} onChange={e => setTotalMarks(e.target.value)} className="w-full px-4 py-3 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] placeholder-[#1A1A1A]/30 focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 transition-all" placeholder="100" required />
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-[#1A1A1A]/70 text-xs font-bold uppercase tracking-wider">Result Photo (Optional)</label>
            <div className="relative border-2 border-dashed border-[#1A1A1A]/10 rounded-2xl p-6 text-center hover:border-[#1A1A1A]/30 hover:bg-white/40 transition-colors group bg-white/20">
              <input type="file" onChange={handleFileChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" accept="image/*" />
              {resultImage ? (
                 <img src={resultImage} alt="Preview" className="h-40 mx-auto object-contain rounded-lg shadow-sm" />
              ) : (
                <div className="flex flex-col items-center">
                  <Upload className="w-6 h-6 text-[#1A1A1A]/60 group-hover:text-[#1A1A1A] mb-2" />
                  <p className="text-[#1A1A1A]/60 text-sm font-medium">{fileName || "Click to upload result image"}</p>
                </div>
              )}
            </div>
          </div>

          <Button type="submit" disabled={loading} className="w-full bg-[#1A1A1A] hover:bg-[#1A1A1A]/90 text-white py-4 rounded-xl font-bold shadow-lg transition-all h-auto">
            <Award className="w-5 h-5 mr-2" />
            {loading ? 'Publishing...' : 'Publish Result'}
          </Button>
        </form>
      </motion.div>
    </>
  );
};

export default ExamResultSender;
