
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, X } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Settings = () => {
  const { user } = useAuth();
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const [password, setPassword] = useState('');
  const { toast } = useToast();

  const handleUpdatePassword = async () => {
    const { error } = await supabase.auth.updateUser({ password });
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
    else {
      toast({ title: "Success", description: "Password updated." });
      setShowSecurityModal(false);
    }
  };

  return (
    <>
      <Helmet><title>Settings - SchoolHub</title></Helmet>
      <div className="max-w-4xl mx-auto space-y-8">
        <h1 className="text-4xl font-bold text-[#1A1A1A]">Settings</h1>
        
        <div className="bg-white/40 backdrop-blur-md border border-[#1A1A1A]/10 rounded-2xl p-8 shadow-lg space-y-4">
          <div className="flex items-center justify-between p-4 bg-white/60 rounded-xl border border-[#1A1A1A]/5">
            <div className="flex items-center gap-4">
              <Shield className="text-green-600 w-6 h-6" />
              <div>
                <h3 className="text-[#1A1A1A] font-medium">Security</h3>
                <p className="text-[#1A1A1A]/70 text-sm">Change password</p>
              </div>
            </div>
            <Button onClick={() => setShowSecurityModal(true)} variant="outline" className="text-[#1A1A1A] border-[#1A1A1A]/20 hover:bg-[#1A1A1A]/5">Manage</Button>
          </div>
        </div>

        <AnimatePresence>
          {showSecurityModal && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white border border-[#1A1A1A]/20 rounded-2xl p-8 max-w-md w-full relative shadow-2xl">
                <button onClick={() => setShowSecurityModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-[#1A1A1A]"><X className="w-5 h-5" /></button>
                
                <div className="space-y-4">
                  <h2 className="text-2xl font-bold text-[#1A1A1A]">Security</h2>
                  <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="New Password" className="w-full p-3 bg-white text-black rounded-xl border border-gray-300 focus:ring-2 focus:ring-[#1A1A1A]" />
                  <Button onClick={handleUpdatePassword} className="w-full bg-[#1A1A1A] text-white hover:bg-[#1A1A1A]/90">Update Password</Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
};

export default Settings;
