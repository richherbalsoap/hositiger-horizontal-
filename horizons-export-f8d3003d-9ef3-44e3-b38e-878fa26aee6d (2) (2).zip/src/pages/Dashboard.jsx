
import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Users, MessageSquare, DollarSign, TrendingUp, Activity, ArrowRight, Calendar } from 'lucide-react';
import { useAppContext } from '@/hooks/useAppContext';
import { Link } from 'react-router-dom';

const StatCard = React.memo(({ icon: Icon, value, label, link, trend }) => (
  <Link to={link} className="block h-full">
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.3 }}
      className="bg-white/40 backdrop-blur-md rounded-2xl p-6 shadow-lg cursor-pointer group transition-all h-full border border-white/30 hover:border-[#1A1A1A]/20 hover:shadow-xl hover:bg-white/50"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-white/60 border border-white/40 flex items-center justify-center shadow-sm group-hover:bg-[#1A1A1A] transition-colors duration-300">
          <Icon className="w-6 h-6 text-[#1A1A1A] group-hover:text-white transition-colors duration-300" />
        </div>
        <div className="flex flex-col items-end">
          <span className="text-4xl font-extrabold text-[#1A1A1A] tracking-tight">{value}</span>
          {trend && (
            <span className="text-xs font-medium text-[#1A1A1A]/60 flex items-center gap-1 bg-green-500/10 px-2 py-0.5 rounded-full mt-1">
              <TrendingUp className="w-3 h-3 text-green-600" />
              {trend}
            </span>
          )}
        </div>
      </div>
      <div className="flex items-center justify-between mt-6">
        <p className="text-[#1A1A1A] font-semibold text-lg">{label}</p>
        <ArrowRight className="w-5 h-5 text-[#1A1A1A]/40 group-hover:text-[#1A1A1A] group-hover:translate-x-1 transition-all" />
      </div>
    </motion.div>
  </Link>
));

const SectionDivider = ({ title }) => (
  <div className="flex items-center gap-4 my-8">
    <div className="h-px bg-gradient-to-r from-transparent via-[#1A1A1A]/20 to-transparent flex-1" />
    <span className="text-[#1A1A1A]/50 text-sm font-bold uppercase tracking-widest">{title}</span>
    <div className="h-px bg-gradient-to-r from-transparent via-[#1A1A1A]/20 to-transparent flex-1" />
  </div>
);

const ACADEMIC_YEARS = ['2022-2023', '2023-2024', '2024-2025', '2025-2026', '2026-2027'];

const Dashboard = () => {
  const { students, complaints, feesReminders } = useAppContext();
  const [selectedYear, setSelectedYear] = useState('2025-2026');

  // Helper to check if a date falls within the selected academic year
  // Assuming Academic Year starts April 1st of the first year and ends March 31st of second year
  const isDateInYear = (dateString) => {
    if (!dateString) return true; // Include if no date
    const date = new Date(dateString);
    const [startYearStr, endYearStr] = selectedYear.split('-');
    const startYear = parseInt(startYearStr);
    const endYear = parseInt(endYearStr);

    // April 1st of Start Year
    const yearStart = new Date(startYear, 3, 1); // Month is 0-indexed, so 3 is April
    // March 31st of End Year
    const yearEnd = new Date(endYear, 2, 31);

    return date >= yearStart && date <= yearEnd;
  };

  const filteredStats = useMemo(() => {
    const filteredStudents = students.filter(s => isDateInYear(s.created_at));
    const filteredComplaints = complaints.filter(c => isDateInYear(c.date || c.created_at));
    const filteredFees = feesReminders.filter(f => isDateInYear(f.created_at));

    return [
      {
        icon: Users,
        label: 'Total Students',
        value: filteredStudents.length,
        link: '/principal-tools/students',
        trend: `Enrolled in ${selectedYear}`
      },
      {
        icon: MessageSquare,
        label: 'Active Complaints',
        value: filteredComplaints.length,
        link: '/complaints-list',
        trend: 'Low priority'
      },
      {
        icon: DollarSign,
        label: 'Fees Pending',
        value: filteredFees.length,
        link: '/teacher-tools/fees',
        trend: 'Action needed'
      }
    ];
  }, [students, complaints, feesReminders, selectedYear]);

  return (
    <>
      <Helmet>
        <title>Dashboard - SchoolHub</title>
        <meta name="description" content="Overview of school management activities and statistics" />
      </Helmet>

      <div className="space-y-8 w-full pb-10">
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between border-b border-[#1A1A1A]/10 pb-6 gap-4">
          <div>
            <h1 className="text-5xl font-extrabold text-[#1A1A1A] mb-2 tracking-tight">
              Dashboard
            </h1>
            <p className="text-[#0F0F0F] text-lg font-medium opacity-70">
              Welcome back to your command center.
            </p>
          </div>
          <div className="flex items-center gap-2 bg-white/30 backdrop-blur-sm px-4 py-2 rounded-lg border border-white/20 text-[#1A1A1A]/80 text-sm font-medium">
             <Calendar className="w-4 h-4 text-[#1A1A1A]" />
             <span>Academic Year:</span>
             <select 
               value={selectedYear}
               onChange={(e) => setSelectedYear(e.target.value)}
               className="bg-transparent font-bold text-[#1A1A1A] outline-none cursor-pointer"
             >
               {ACADEMIC_YEARS.map(year => (
                 <option key={year} value={year}>{year}</option>
               ))}
             </select>
          </div>
        </div>

        <SectionDivider title={`Key Metrics for ${selectedYear}`} />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full">
          {filteredStats.map((stat, index) => (
            <StatCard key={index} {...stat} />
          ))}
        </div>

        <SectionDivider title="Quick Actions" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link to="/teacher-tools/homework" className="bg-white/40 hover:bg-white/60 backdrop-blur-md p-6 rounded-2xl border border-white/30 transition-all group flex items-center justify-between">
            <div className="flex items-center gap-4">
               <div className="p-3 bg-[#1A1A1A]/5 rounded-xl group-hover:bg-[#1A1A1A]/10 transition-colors">
                 <Activity className="w-6 h-6 text-[#1A1A1A]" />
               </div>
               <div>
                 <h3 className="text-[#1A1A1A] font-bold text-lg">Send Homework</h3>
                 <p className="text-[#1A1A1A]/60 text-sm">Create and distribute assignments</p>
               </div>
            </div>
            <ArrowRight className="text-[#1A1A1A]/40 group-hover:text-[#1A1A1A] transition-colors" />
          </Link>

          <Link to="/principal-tools/analytics" className="bg-white/40 hover:bg-white/60 backdrop-blur-md p-6 rounded-2xl border border-white/30 transition-all group flex items-center justify-between">
            <div className="flex items-center gap-4">
               <div className="p-3 bg-[#1A1A1A]/5 rounded-xl group-hover:bg-[#1A1A1A]/10 transition-colors">
                 <TrendingUp className="w-6 h-6 text-[#1A1A1A]" />
               </div>
               <div>
                 <h3 className="text-[#1A1A1A] font-bold text-lg">View Analytics</h3>
                 <p className="text-[#1A1A1A]/60 text-sm">Check performance reports</p>
               </div>
            </div>
            <ArrowRight className="text-[#1A1A1A]/40 group-hover:text-[#1A1A1A] transition-colors" />
          </Link>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
