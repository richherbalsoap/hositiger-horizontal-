
import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useAppContext } from '@/hooks/useAppContext';
import { STANDARDS, SECTIONS } from '@/lib/utils';
import { Filter, MessageCircle } from 'lucide-react';

const ComplaintsList = () => {
  const { complaints, students } = useAppContext();
  const [filterStandard, setFilterStandard] = useState('All');
  const [filterClass, setFilterClass] = useState('All');

  const filteredComplaints = useMemo(() => {
    return complaints.filter(complaint => {
      const standardMatch = filterStandard === 'All' || complaint.standard === filterStandard;
      const classMatch = filterClass === 'All' || complaint.class_section === filterClass;
      return standardMatch && classMatch;
    });
  }, [complaints, filterStandard, filterClass]);

  const getStudentName = (id) => {
    const student = students.find(s => s.id === id);
    return student ? student.name : 'Unknown Student';
  };

  return (
    <>
      <Helmet>
        <title>Complaints List - SchoolHub</title>
      </Helmet>
      <div className="space-y-8 w-full">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end border-b border-[#1A1A1A]/10 pb-6">
          <div>
            <h1 className="text-4xl font-extrabold text-[#1A1A1A] mb-2 tracking-tight">
              Complaints Log
            </h1>
            <p className="text-[#1A1A1A]/70 text-lg">View and resolve student grievances</p>
          </div>
          <div className="flex items-center gap-2 mt-4 md:mt-0">
             <div className="bg-white/40 backdrop-blur-md border border-[#1A1A1A]/10 rounded-lg px-3 py-1 text-sm font-semibold text-[#1A1A1A]">
               Total: {filteredComplaints.length}
             </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-6 w-full">
          <div className="flex items-center bg-white/40 backdrop-blur-md rounded-xl px-4 py-3 border border-[#1A1A1A]/10 w-full sm:w-auto shadow-sm">
            <Filter className="w-4 h-4 text-[#1A1A1A]/60 mr-2" />
            <select
              value={filterStandard}
              onChange={(e) => setFilterStandard(e.target.value)}
              className="bg-transparent text-[#1A1A1A] focus:outline-none w-full font-medium"
            >
              <option value="All" className="text-gray-600">All Standards</option>
              {STANDARDS.map(std => (
                <option key={std} value={std} className="text-gray-600">{std}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center bg-white/40 backdrop-blur-md rounded-xl px-4 py-3 border border-[#1A1A1A]/10 w-full sm:w-auto shadow-sm">
            <Filter className="w-4 h-4 text-[#1A1A1A]/60 mr-2" />
            <select
              value={filterClass}
              onChange={(e) => setFilterClass(e.target.value)}
              className="bg-transparent text-[#1A1A1A] focus:outline-none w-full font-medium"
            >
              <option value="All" className="text-gray-600">All Classes</option>
              {SECTIONS.map(sec => (
                <option key={sec} value={sec} className="text-gray-600">{sec}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="bg-white/40 backdrop-blur-xl border border-white/50 rounded-2xl p-6 shadow-xl overflow-hidden">
          <div className="overflow-x-auto w-full">
            <table className="w-full text-left min-w-[800px]">
              <thead>
                <tr className="border-b border-[#1A1A1A]/10 text-[#1A1A1A]/60 uppercase text-xs tracking-wider">
                  <th className="p-4 font-bold">Student</th>
                  <th className="p-4 font-bold">Details</th>
                  <th className="p-4 font-bold">Complaint</th>
                  <th className="p-4 font-bold">Date</th>
                  <th className="p-4 font-bold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1A1A]/5">
                {filteredComplaints.length > 0 ? (
                  filteredComplaints.map((complaint, index) => (
                    <motion.tr 
                      key={index}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.05 }}
                      className="hover:bg-white/40 transition-colors"
                    >
                      <td className="p-4 text-[#1A1A1A] font-bold">{getStudentName(complaint.student_id)}</td>
                      <td className="p-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-[#1A1A1A]/5 text-[#1A1A1A]/80">
                          {complaint.standard} - {complaint.class_section}
                        </span>
                      </td>
                      <td className="p-4">
                         <div className="flex items-start gap-2 max-w-md">
                           <MessageCircle className="w-4 h-4 text-[#1A1A1A]/40 mt-1 flex-shrink-0" />
                           <p className="text-[#1A1A1A]/80 text-sm leading-relaxed">{complaint.message}</p>
                         </div>
                      </td>
                      <td className="p-4 text-[#1A1A1A]/60 text-sm">{complaint.date || 'Today'}</td>
                      <td className="p-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          Pending
                        </span>
                      </td>
                    </motion.tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="p-12 text-center text-[#1A1A1A]/40">
                       <p className="text-lg font-medium">No complaints found</p>
                       <p className="text-sm">Great job keeping everyone happy!</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};

export default ComplaintsList;
