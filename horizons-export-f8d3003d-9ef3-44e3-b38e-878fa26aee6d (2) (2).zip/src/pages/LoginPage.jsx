
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { GraduationCap, Mail, Lock, Loader2, ArrowRight } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast({ 
        title: "Error", 
        description: "Please enter both email and password.", 
        variant: "destructive" 
      });
      return;
    }

    setLoading(true);
    
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      toast({ title: "Success", description: "Login successful! Redirecting..." });
      navigate('/dashboard');
    } catch (error) {
      toast({ 
        title: "Login Failed", 
        description: error.message || "Invalid credentials. Please try again.", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>Login - SchoolHub</title></Helmet>
      
      <div 
        className="min-h-screen w-full flex items-center justify-center p-4 relative"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1687600154329-150952c73169')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      >
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />

        <motion.div 
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="w-full max-w-md bg-white rounded-3xl p-8 shadow-2xl relative z-10"
        >
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF8C42] to-[#00D9FF] flex items-center justify-center shadow-lg">
              <GraduationCap className="w-8 h-8 text-white" />
            </div>
          </div>
          
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-black mb-2">Welcome Back</h1>
            <p className="text-gray-600 font-medium">Enter your credentials to access your account</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-black text-sm font-bold mb-2 ml-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-4 top-3.5 w-5 h-5 text-gray-500" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl text-black placeholder:text-gray-400 focus:ring-2 focus:ring-black focus:border-black outline-none transition-all font-medium"
                  placeholder="name@school.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-black text-sm font-bold mb-2 ml-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 w-5 h-5 text-gray-500" />
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl text-black placeholder:text-gray-400 focus:ring-2 focus:ring-black focus:border-black outline-none transition-all font-medium"
                  placeholder="Enter your password"
                  required
                />
              </div>
            </div>

            <Button 
              type="submit" 
              disabled={loading} 
              className="w-full bg-black hover:bg-gray-800 text-white py-6 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transition-all"
            >
              {loading ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                'Login'
              )}
            </Button>
          </form>

          <div className="mt-8 text-center border-t border-gray-100 pt-6">
            <Link 
              to="/forgot-password" 
              className="text-sm font-semibold text-gray-500 hover:text-black transition-colors flex items-center justify-center gap-1 group"
            >
              Forgot Password?
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default LoginPage;
