
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Lock, Loader2, Save } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const ResetPasswordPage = () => {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleUpdatePassword = async (e) => {
    e.preventDefault();
    
    if (newPassword !== confirmPassword) {
      toast({ 
        title: "Mismatch", 
        description: "Passwords do not match.", 
        variant: "destructive" 
      });
      return;
    }

    if (newPassword.length < 8) {
      toast({ 
        title: "Weak Password", 
        description: "Password must be at least 8 characters long.", 
        variant: "destructive" 
      });
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });

      if (error) throw error;

      toast({ 
        title: "Success", 
        description: "Password updated successfully! Please log in." 
      });
      
      // Give the user a moment to see the success message
      setTimeout(() => navigate('/login'), 2000);
    } catch (error) {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to update password.", 
        variant: "destructive" 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>Set New Password - SchoolHub</title></Helmet>
      
      <div 
        className="min-h-screen w-full flex items-center justify-center p-4 relative"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1687600154329-150952c73169')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      >
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" />

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }} 
          animate={{ opacity: 1, scale: 1 }} 
          className="w-full max-w-md bg-white rounded-3xl p-8 shadow-2xl relative z-10"
        >
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-black mb-2">Set New Password</h1>
            <p className="text-gray-600 text-sm">
              Please enter your new password below.
            </p>
          </div>

          <form onSubmit={handleUpdatePassword} className="space-y-4">
            <div>
              <label className="block text-black text-sm font-bold mb-2">New Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl text-black focus:ring-2 focus:ring-black focus:border-black outline-none transition-all font-medium"
                  placeholder="At least 8 characters"
                  required
                  minLength={8}
                />
              </div>
            </div>

            <div>
              <label className="block text-black text-sm font-bold mb-2">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl text-black focus:ring-2 focus:ring-black focus:border-black outline-none transition-all font-medium"
                  placeholder="Re-enter password"
                  required
                />
              </div>
            </div>

            <Button 
              type="submit" 
              disabled={loading} 
              className="w-full bg-black hover:bg-gray-800 text-white py-6 rounded-xl font-bold disabled:opacity-70"
            >
              {loading ? <Loader2 className="animate-spin" /> : (
                <span className="flex items-center gap-2">
                  <Save className="w-4 h-4" /> Reset Password
                </span>
              )}
            </Button>
          </form>
        </motion.div>
      </div>
    </>
  );
};

export default ResetPasswordPage;
