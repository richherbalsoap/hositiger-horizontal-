
import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend 
} from 'recharts';
import { motion } from 'framer-motion';
import { TrendingUp, Users, Award, BookOpen, Filter, Loader2, AlertCircle } from 'lucide-react';
import { STANDARDS, SECTIONS, SUBJECTS } from '@/lib/utils';
import { supabase } from '@/lib/customSupabaseClient';

const COLORS = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F'];

const Analytics = () => {
  const [standard, setStandard] = useState('All');
  const [section, setSection] = useState('All');
  const [subjectFilter, setSubjectFilter] = useState('All');
  const [resultsData, setResultsData] = useState([]);
  const [studentsData, setStudentsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const [resultsResult, studentsResult] = await Promise.all([
           supabase
            .from('results')
            .select(`
              *,
              students (
                name
              )
            `),
           supabase.from('students').select('*')
        ]);
        
        if (resultsResult.error) throw resultsResult.error;
        if (studentsResult.error) throw studentsResult.error;

        setResultsData(resultsResult.data || []);
        setStudentsData(studentsResult.data || []);
      } catch (err) {
        console.error('Error fetching analytics data:', err);
        setError('Failed to load analytics data.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const filteredResults = useMemo(() => {
    return resultsData.filter(r => {
      const stdMatch = standard === 'All' || r.standard === standard;
      const secMatch = section === 'All' || r.class_section === section;
      const subMatch = subjectFilter === 'All' || r.subject === subjectFilter;
      return stdMatch && secMatch && subMatch;
    });
  }, [resultsData, standard, section, subjectFilter]);

  const kpiData = useMemo(() => {
    if (filteredResults.length === 0) {
      return { totalStudents: 0, avgScore: 0, passRate: 0, topPerformer: 'N/A' };
    }

    const uniqueStudents = new Set(filteredResults.map(r => r.student_id)).size;
    const totalMarks = filteredResults.reduce((acc, curr) => acc + Number(curr.marks), 0);
    const totalMaxMarks = filteredResults.reduce((acc, curr) => acc + Number(curr.total_marks || 100), 0);
    const avgScore = totalMaxMarks ? Math.round((totalMarks / totalMaxMarks) * 100) : 0;
    
    const passedCount = filteredResults.filter(r => (Number(r.marks) / Number(r.total_marks || 100)) >= 0.4).length;
    const passRate = filteredResults.length ? Math.round((passedCount / filteredResults.length) * 100) : 0;

    const studentTotals = {};
    filteredResults.forEach(r => {
      const name = r.students?.name || 'Unknown';
      if (!studentTotals[name]) studentTotals[name] = 0;
      studentTotals[name] += Number(r.marks);
    });
    
    const topPerformerEntry = Object.entries(studentTotals).sort((a, b) => b[1] - a[1])[0];
    const topPerformer = topPerformerEntry ? topPerformerEntry[0] : 'N/A';

    return { totalStudents: uniqueStudents, avgScore, passRate, topPerformer };
  }, [filteredResults]);

  const subjectPerformance = useMemo(() => {
    const subjects = {};
    filteredResults.forEach(r => {
      if (!subjects[r.subject]) subjects[r.subject] = { total: 0, count: 0, max: 0, min: 100 };
      subjects[r.subject].total += Number(r.marks);
      subjects[r.subject].count += 1;
      subjects[r.subject].max = Math.max(subjects[r.subject].max, Number(r.marks));
      subjects[r.subject].min = Math.min(subjects[r.subject].min, Number(r.marks));
    });
    return Object.keys(subjects).map(sub => ({
      name: sub,
      avg: Math.round(subjects[sub].total / subjects[sub].count),
      max: subjects[sub].max,
      min: subjects[sub].min
    }));
  }, [filteredResults]);

  const performanceTrend = useMemo(() => {
    if (filteredResults.length === 0) return [];
    const months = {};
    filteredResults.forEach(r => {
      if (!r.date) return;
      const date = new Date(r.date);
      const monthKey = date.toLocaleString('default', { month: 'short', year: 'numeric' });
      const sortKey = date.getTime();
      if (!months[monthKey]) months[monthKey] = { total: 0, count: 0, timestamp: sortKey };
      months[monthKey].total += Number(r.marks);
      months[monthKey].count += 1;
    });

    return Object.entries(months)
      .map(([key, data]) => ({
        name: key,
        score: Math.round(data.total / data.count),
        timestamp: data.timestamp
      }))
      .sort((a, b) => a.timestamp - b.timestamp);
  }, [filteredResults]);

  const classDistribution = useMemo(() => {
    const classes = {};
    const dataToUse = studentsData.length > 0 ? studentsData : [];
    
    dataToUse.forEach(s => {
      const key = `${s.standard}-${s.class_section}`;
      if (!classes[key]) classes[key] = 0;
      classes[key] += 1;
    });

    // If no student data is available, fall back to results data or return empty
    if (Object.keys(classes).length === 0) return [];

    return Object.keys(classes)
      .map(c => ({ name: c, value: classes[c] }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6); 
  }, [studentsData]);

  return (
    <>
      <Helmet><title>Analytics & Reports - SchoolHub</title></Helmet>
      
      <div className="space-y-8 pb-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-[#1A1A1A]/10 pb-6">
          <div>
            <h1 className="text-4xl font-extrabold text-[#1A1A1A] tracking-tight">
              Analytics Dashboard
            </h1>
            <p className="text-[#1A1A1A]/70 mt-1 font-medium">Insights and performance metrics</p>
          </div>
          
          <div className="flex flex-wrap gap-2 bg-white/40 backdrop-blur-md p-2 rounded-xl border border-[#1A1A1A]/10 shadow-sm">
            <div className="flex items-center px-3 border-r border-[#1A1A1A]/10">
              <Filter className="w-4 h-4 text-[#1A1A1A] mr-2" />
              <span className="text-sm font-bold text-[#1A1A1A]">Filters</span>
            </div>
            
            <select value={standard} onChange={e => setStandard(e.target.value)} className="bg-transparent text-[#1A1A1A] text-sm font-medium border-none rounded-lg px-3 py-1.5 focus:ring-1 focus:ring-[#1A1A1A]/20 cursor-pointer">
              <option value="All" className="text-gray-600">All Standards</option>
              {STANDARDS.map(s => <option key={s} value={s} className="text-gray-600">{s}</option>)}
            </select>
            
            <select value={section} onChange={e => setSection(e.target.value)} className="bg-transparent text-[#1A1A1A] text-sm font-medium border-none rounded-lg px-3 py-1.5 focus:ring-1 focus:ring-[#1A1A1A]/20 cursor-pointer">
              <option value="All" className="text-gray-600">All Sections</option>
              {SECTIONS.map(s => <option key={s} value={s} className="text-gray-600">{s}</option>)}
            </select>

            <select value={subjectFilter} onChange={e => setSubjectFilter(e.target.value)} className="bg-transparent text-[#1A1A1A] text-sm font-medium border-none rounded-lg px-3 py-1.5 focus:ring-1 focus:ring-[#1A1A1A]/20 cursor-pointer">
              <option value="All" className="text-gray-600">All Subjects</option>
              {SUBJECTS.map(s => <option key={s} value={s} className="text-gray-600">{s}</option>)}
            </select>
          </div>
        </div>

        {loading && (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="w-8 h-8 text-[#1A1A1A] animate-spin" />
          </div>
        )}

        {!loading && error && (
          <div className="bg-red-50 border border-red-200 p-4 rounded-xl flex items-center gap-3 text-red-600">
            <AlertCircle className="w-5 h-5" />
            {error}
          </div>
        )}

        {!loading && !error && (
          <>
            {filteredResults.length === 0 ? (
               <div className="bg-white/40 backdrop-blur-xl border border-white/50 rounded-2xl p-12 text-center">
                 <div className="w-16 h-16 bg-[#1A1A1A]/5 rounded-full flex items-center justify-center mx-auto mb-4">
                   <BookOpen className="w-8 h-8 text-[#1A1A1A]/40" />
                 </div>
                 <h3 className="text-xl font-bold text-[#1A1A1A] mb-2">No Data Available</h3>
                 <p className="text-[#1A1A1A]/60">
                   There are no exam results matching your selected filters.
                 </p>
               </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <KPICard title="Avg Score" value={`${kpiData.avgScore}%`} icon={<TrendingUp className="text-[#1A1A1A]" />} subtitle="Overall Performance" />
                  <KPICard title="Pass Rate" value={`${kpiData.passRate}%`} icon={<BookOpen className="text-[#1A1A1A]" />} subtitle="Based on 40% cutoff" />
                  <KPICard title="Total Students" value={kpiData.totalStudents} icon={<Users className="text-[#1A1A1A]" />} subtitle="In selected filter" />
                  <KPICard title="Top Performer" value={kpiData.topPerformer} icon={<Award className="text-[#1A1A1A]" />} subtitle="Highest Total Marks" />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <ChartCard title="Subject-wise Performance (Average)">
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={subjectPerformance}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                        <XAxis dataKey="name" stroke="#666" fontSize={12} tickLine={false} />
                        <YAxis stroke="#666" fontSize={12} tickLine={false} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#fff', border: '1px solid #ddd', borderRadius: '8px', color: '#1A1A1A' }}
                          cursor={{ fill: 'rgba(0,0,0,0.05)' }}
                        />
                        <Bar dataKey="avg" fill="#FF6B6B" radius={[4, 4, 0, 0]} barSize={40} />
                      </BarChart>
                    </ResponsiveContainer>
                  </ChartCard>

                  <ChartCard title="Performance Trends">
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={performanceTrend}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                        <XAxis dataKey="name" stroke="#666" fontSize={12} tickLine={false} />
                        <YAxis stroke="#666" fontSize={12} tickLine={false} />
                        <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #ddd', color: '#1A1A1A' }} />
                        <Line type="monotone" dataKey="score" stroke="#4ECDC4" strokeWidth={3} dot={{ fill: '#4ECDC4', strokeWidth: 2 }} activeDot={{ r: 6 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartCard>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <ChartCard title="Class Distribution (Enrollment)">
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={classDistribution}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                            label={({ name, percent }) => `${name}`}
                          >
                            {classDistribution.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #ddd', color: '#1A1A1A' }} />
                          <Legend verticalAlign="bottom" height={36} />
                        </PieChart>
                    </ResponsiveContainer>
                  </ChartCard>

                  <div className="lg:col-span-2 bg-white/40 backdrop-blur-xl border border-white/50 rounded-2xl p-6 shadow-lg overflow-hidden flex flex-col">
                    <h3 className="text-xl font-bold text-[#1A1A1A] mb-4 flex items-center gap-2">
                      <Users className="w-5 h-5 text-[#1A1A1A]/70" />
                      Recent Results Log
                    </h3>
                    <div className="overflow-y-auto flex-1 max-h-[300px]">
                      <table className="w-full text-left border-collapse">
                        <thead className="sticky top-0 bg-white/80 backdrop-blur-md z-10">
                          <tr className="text-[#1A1A1A]/60 text-sm border-b border-[#1A1A1A]/10">
                            <th className="p-3 font-bold">Student</th>
                            <th className="p-3 font-bold">Class</th>
                            <th className="p-3 font-bold">Subject</th>
                            <th className="p-3 font-bold">Marks</th>
                            <th className="p-3 font-bold">Status</th>
                          </tr>
                        </thead>
                        <tbody className="text-sm">
                          {filteredResults.slice(0, 50).map((r, i) => { 
                            const percentage = (Number(r.marks) / Number(r.total_marks || 100)) * 100;
                            const status = percentage >= 40 ? 'Pass' : 'Fail';
                            return (
                              <tr key={i} className="border-b border-[#1A1A1A]/5 hover:bg-[#1A1A1A]/5 transition-colors">
                                <td className="p-3 text-[#1A1A1A] font-semibold">{r.students?.name || 'Unknown'}</td>
                                <td className="p-3 text-[#1A1A1A]/80">{r.standard}-{r.class_section}</td>
                                <td className="p-3 text-[#1A1A1A]/80">{r.subject}</td>
                                <td className="p-3 font-bold text-[#1A1A1A]">{r.marks}</td>
                                <td className="p-3">
                                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${status === 'Pass' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                    {status}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </>
            )}
          </>
        )}
      </div>
    </>
  );
};

const KPICard = ({ title, value, icon, subtitle }) => (
  <motion.div 
    whileHover={{ scale: 1.02 }}
    className="bg-white/40 backdrop-blur-md rounded-2xl p-6 shadow-sm border border-white/50 relative overflow-hidden group hover:shadow-md transition-all"
  >
    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
      {React.cloneElement(icon, { size: 60 })}
    </div>
    <div className="flex justify-between items-start mb-4">
      <div className="p-3 bg-[#1A1A1A]/5 rounded-xl text-[#1A1A1A]">
        {React.cloneElement(icon, { size: 24 })}
      </div>
    </div>
    <h3 className="text-[#1A1A1A]/60 text-sm font-bold uppercase tracking-wider">{title}</h3>
    <div className="text-3xl font-extrabold text-[#1A1A1A] mt-1 mb-1">{value}</div>
    <p className="text-xs text-[#1A1A1A]/50 font-medium">{subtitle}</p>
  </motion.div>
);

const ChartCard = ({ title, children }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="bg-white/40 backdrop-blur-xl rounded-2xl p-6 shadow-lg border border-white/50"
  >
    <h3 className="text-lg font-bold text-[#1A1A1A] mb-6">{title}</h3>
    {children}
  </motion.div>
);

export default Analytics;
