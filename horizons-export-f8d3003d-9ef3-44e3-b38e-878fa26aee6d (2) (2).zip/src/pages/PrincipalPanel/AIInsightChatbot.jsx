
import React, { useState, useRef, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Send, Bot, User, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/customSupabaseClient';

const AIInsightChatbot = () => {
  const [messages, setMessages] = useState([
    { 
      id: 1, 
      role: 'assistant', 
      content: 'Hello! I am your AI assistant. I have access to the latest exam results. Ask me about student performance, class analysis, or specific insights!', 
      timestamp: new Date() 
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [realData, setRealData] = useState([]);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    fetchRealData();
    const subscription = supabase
      .channel('results-changes')
      .on(
        'postgres_changes', 
        { event: '*', schema: 'public', table: 'results' }, 
        () => fetchRealData()
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchRealData = async () => {
    const { data, error } = await supabase
      .from('results')
      .select(`*, students (name, standard, class_section)`);
    if (!error && data) setRealData(data);
  };

  useEffect(() => { 
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); 
  }, [messages, isTyping]);

  const processAIResponse = (userQuestion, data) => {
    const lowerQ = userQuestion.toLowerCase();
    
    if (data.length === 0) return "I don't have any exam result data to analyze yet.";

    // 1. Weak/Strong subjects
    if (lowerQ.includes('weak') || lowerQ.includes('difficult') || lowerQ.includes('improvement')) {
      const subjectStats = {};
      data.forEach(r => {
        if (!subjectStats[r.subject]) subjectStats[r.subject] = { total: 0, count: 0 };
        subjectStats[r.subject].total += Number(r.marks);
        subjectStats[r.subject].count++;
      });
      
      let weakest = { name: '', avg: 100 };
      Object.entries(subjectStats).forEach(([name, stats]) => {
        const avg = stats.total / stats.count;
        if (avg < weakest.avg) weakest = { name, avg };
      });
      
      return `Based on real performance data, students are struggling most with **${weakest.name}** (Avg: ${weakest.avg.toFixed(1)}%). I recommend scheduling extra remedial classes for ${weakest.name}.`;
    }

    // 2. Strongest Subject
    if (lowerQ.includes('strong') || lowerQ.includes('best subject')) {
        const subjectStats = {};
        data.forEach(r => {
          if (!subjectStats[r.subject]) subjectStats[r.subject] = { total: 0, count: 0 };
          subjectStats[r.subject].total += Number(r.marks);
          subjectStats[r.subject].count++;
        });
        
        let strongest = { name: '', avg: 0 };
        Object.entries(subjectStats).forEach(([name, stats]) => {
          const avg = stats.total / stats.count;
          if (avg > strongest.avg) strongest = { name, avg };
        });
        
        return `Students are performing exceptionally well in **${strongest.name}** with an average score of ${strongest.avg.toFixed(1)}%. Keep up the great work!`;
    }

    // 3. Top Student
    if (lowerQ.includes('top') || lowerQ.includes('best student') || lowerQ.includes('highest')) {
       const studentTotals = {};
       data.forEach(r => {
         const name = r.students?.name || 'Unknown';
         if (!studentTotals[name]) studentTotals[name] = 0;
         studentTotals[name] += Number(r.marks);
       });
       
       const topStudent = Object.entries(studentTotals).sort((a,b) => b[1] - a[1])[0];
       if (topStudent) {
         return `The top performing student is **${topStudent[0]}** with a total score of ${topStudent[1]}.`;
       }
    }

    // 4. General Performance
    if (lowerQ.includes('perform') || lowerQ.includes('summary') || lowerQ.includes('status')) {
       const totalMarks = data.reduce((acc, curr) => acc + Number(curr.marks), 0);
       const avgScore = (totalMarks / data.length).toFixed(1);
       return `I analyzed ${data.length} exam records. The overall school average is **${avgScore}**. We have data covering subjects like ${[...new Set(data.map(d => d.subject))].join(', ')}.`;
    }

    return "I can analyze student performance from the database. Try asking about 'weakest subjects', 'top student', or 'overall performance'.";
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = { id: Date.now(), role: 'user', content: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const responseText = processAIResponse(userMsg.content, realData);
      const aiMsg = { id: Date.now() + 1, role: 'assistant', content: responseText, timestamp: new Date() };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <>
      <Helmet><title>AI Insights - SchoolHub</title></Helmet>
      
      <div className="max-w-5xl mx-auto h-[calc(100vh-100px)] flex flex-col gap-4 py-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white/40 backdrop-blur-xl p-6 rounded-2xl shadow-lg border border-white/50">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-white border border-[#1A1A1A]/10 flex items-center justify-center shadow-sm">
              <Bot className="w-7 h-7 text-[#1A1A1A]" />
            </div>
            <div>
              <h1 className="text-2xl font-extrabold text-[#1A1A1A] flex items-center gap-2">
                SchoolHub AI
                <Sparkles className="w-4 h-4 text-[#1A1A1A]/40" />
              </h1>
              <p className="text-[#1A1A1A]/60 text-sm font-medium">Powered by Real-Time Data</p>
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 bg-white/40 backdrop-blur-xl rounded-2xl shadow-xl border border-white/50 overflow-hidden flex flex-col relative">
           {/* Messages */}
           <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {messages.map((m) => (
              <motion.div 
                key={m.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] md:max-w-[70%] flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  {/* Avatar */}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${
                    m.role === 'user' ? 'bg-[#1A1A1A]' : 'bg-white'
                  }`}>
                    {m.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-[#1A1A1A]" />}
                  </div>

                  {/* Bubble */}
                  <div className={`p-4 rounded-2xl shadow-sm ${
                    m.role === 'user' 
                      ? 'bg-[#1A1A1A] text-white rounded-tr-none' 
                      : 'bg-white border border-[#1A1A1A]/5 text-[#1A1A1A] rounded-tl-none'
                  }`}>
                    <p className="whitespace-pre-line leading-relaxed text-sm md:text-base font-medium">{m.content}</p>
                    <span className={`text-[10px] block mt-2 opacity-60 ${m.role === 'user' ? 'text-white/60' : 'text-[#1A1A1A]/40'}`}>
                      {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}

            {isTyping && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start gap-3">
                <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center flex-shrink-0 shadow-sm">
                  <Bot className="w-4 h-4 text-[#1A1A1A]" />
                </div>
                <div className="bg-white border border-[#1A1A1A]/5 px-4 py-3 rounded-2xl rounded-tl-none flex gap-1 items-center shadow-sm">
                  <span className="w-2 h-2 bg-[#1A1A1A]/40 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-2 h-2 bg-[#1A1A1A]/40 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-2 h-2 bg-[#1A1A1A]/40 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-[#1A1A1A]/5 bg-white/60 backdrop-blur-md">
            <form onSubmit={handleSubmit} className="relative flex gap-2 max-w-4xl mx-auto">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 bg-white border border-[#1A1A1A]/10 rounded-xl pl-5 pr-12 py-4 placeholder-[#1A1A1A]/30 text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 shadow-sm"
                placeholder="Ask for insights about class performance..."
                disabled={isTyping}
              />
              <Button 
                type="submit" 
                disabled={!input.trim() || isTyping}
                className="absolute right-2 top-2 bottom-2 bg-[#1A1A1A] hover:bg-[#1A1A1A]/90 text-white rounded-lg px-4 transition-all disabled:opacity-50 disabled:cursor-not-allowed aspect-square flex items-center justify-center shadow-sm"
              >
                <Send className="w-5 h-5" />
              </Button>
            </form>
            <div className="text-center mt-2">
              <p className="text-[10px] text-[#1A1A1A]/40 font-medium">AI analysis based on live database records.</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AIInsightChatbot;
