
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit, Trash2, X, Upload, Loader2, User, Phone, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAppContext } from '@/hooks/useAppContext';
import { STANDARDS, SECTIONS } from '@/lib/utils';
import { supabase } from '@/lib/customSupabaseClient';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';

const StudentManagement = () => {
  const [showModal, setShowModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    standard: '',
    class_section: '',
    parent_phone: '',
    parent_name: '',
    photo_url: ''
  });
  const [uploading, setUploading] = useState(false);

  const { toast } = useToast();
  const { students, addStudent, updateStudent, deleteStudent } = useAppContext();

  const handleFileUpload = async (e) => {
    try {
      setUploading(true);
      const file = e.target.files[0];
      if (!file) return;

      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('students')
        .upload(filePath, file);

      if (uploadError) {
        throw uploadError;
      }

      const { data } = supabase.storage
        .from('students')
        .getPublicUrl(filePath);

      setFormData(prev => ({ ...prev, photo_url: data.publicUrl }));
      toast({ title: "Photo Uploaded", description: "Student photo uploaded successfully." });
    } catch (error) {
      toast({ 
        title: "Upload Failed", 
        description: error.message || "Could not upload photo", 
        variant: "destructive" 
      });
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingStudent) {
      await updateStudent(editingStudent.id, formData);
      toast({ title: "Student Updated", description: "Records updated." });
    } else {
      await addStudent(formData);
      toast({ title: "Student Added", description: "New student added." });
    }
    setShowModal(false);
    setEditingStudent(null);
    setFormData({ name: '', standard: '', class_section: '', parent_phone: '', parent_name: '', photo_url: '' });
  };

  const handleEdit = (student) => {
    setEditingStudent(student);
    setFormData({
      name: student.name,
      standard: student.standard,
      class_section: student.class_section,
      parent_phone: student.parent_phone,
      parent_name: student.parent_name,
      photo_url: student.photo_url || ''
    });
    setShowModal(true);
  };

  const handleDelete = async (student) => {
    if (window.confirm(`Delete ${student.name}?`)) {
      await deleteStudent(student.id);
      toast({ title: "Deleted", description: "Student removed.", variant: "destructive" });
    }
  };

  return (
    <>
      <Helmet>
        <title>Student Management - SchoolHub</title>
      </Helmet>

      <div className="space-y-8 w-full px-4 sm:px-0 pb-20 sm:pb-0">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-[#1A1A1A]/10 pb-6">
          <div className="w-full sm:w-auto">
            <h1 className="text-3xl sm:text-4xl font-extrabold text-[#1A1A1A] mb-2 tracking-tight">
              Student Management
            </h1>
            <p className="text-[#0F0F0F]/70 text-base sm:text-lg font-medium">Manage student records</p>
          </div>

          <Button
            onClick={() => {
              setEditingStudent(null);
              setFormData({ name: '', standard: '', class_section: '', parent_phone: '', parent_name: '', photo_url: '' });
              setShowModal(true);
            }}
            className="w-full sm:w-auto bg-[#1A1A1A] text-white hover:bg-[#1A1A1A]/90 shadow-lg py-6 sm:py-4 text-base font-semibold"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Student
          </Button>
        </div>

        {/* Desktop View - Table */}
        <div className="hidden md:block bg-white/40 backdrop-blur-xl rounded-2xl p-6 shadow-xl border border-white/30 overflow-hidden">
          <div className="overflow-x-auto w-full">
            <table className="w-full text-left min-w-[800px]">
              <thead>
                <tr className="border-b border-[#1A1A1A]/10 text-[#1A1A1A]/60 uppercase text-xs tracking-wider">
                  <th className="p-4 font-bold">Student</th>
                  <th className="p-4 font-bold">Standard</th>
                  <th className="p-4 font-bold">Class</th>
                  <th className="p-4 font-bold">Parent Name</th>
                  <th className="p-4 font-bold">Phone</th>
                  <th className="p-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1A1A]/5">
                {students.map((student) => (
                  <tr key={student.id} className="hover:bg-white/40 transition-colors group">
                    <td className="p-4 text-[#1A1A1A] font-bold flex items-center gap-4">
                       <Avatar className="h-10 w-10 border border-[#1A1A1A]/10 shadow-sm">
                          <AvatarImage src={student.photo_url} alt={student.name} />
                          <AvatarFallback className="bg-[#1A1A1A]/10 text-[#1A1A1A]">
                            {student.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <span>{student.name}</span>
                    </td>
                    <td className="p-4 text-[#1A1A1A]/80 font-medium">{student.standard}</td>
                    <td className="p-4 text-[#1A1A1A]/80 font-medium">{student.class_section}</td>
                    <td className="p-4 text-[#1A1A1A]/80 font-medium">{student.parent_name}</td>
                    <td className="p-4 text-[#1A1A1A]/80 font-medium font-mono text-sm">{student.parent_phone}</td>
                    <td className="p-4 flex justify-end gap-2 opacity-60 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => handleEdit(student)} className="text-[#1A1A1A] p-2 hover:bg-[#1A1A1A]/10 rounded-lg transition-colors"><Edit className="w-4 h-4" /></button>
                      <button onClick={() => handleDelete(student)} className="text-red-600 p-2 hover:bg-red-500/10 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Mobile View - Cards */}
        <div className="md:hidden grid grid-cols-1 sm:grid-cols-2 gap-4">
          {students.map((student) => (
            <motion.div 
              key={student.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/40 backdrop-blur-xl rounded-2xl p-5 shadow-sm border border-white/30 flex flex-col gap-4"
            >
              <div className="flex items-center gap-4">
                <Avatar className="h-14 w-14 border-2 border-white shadow-sm">
                  <AvatarImage src={student.photo_url} alt={student.name} />
                  <AvatarFallback className="bg-[#1A1A1A]/10 text-[#1A1A1A] text-lg">
                    {student.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-[#1A1A1A] font-bold text-lg leading-tight">{student.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="bg-[#1A1A1A]/5 text-[#1A1A1A]/80 text-xs font-bold px-2 py-0.5 rounded-full border border-[#1A1A1A]/5">
                      Class {student.standard}
                    </span>
                    <span className="bg-[#1A1A1A]/5 text-[#1A1A1A]/80 text-xs font-bold px-2 py-0.5 rounded-full border border-[#1A1A1A]/5">
                      Sec {student.class_section}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 bg-white/30 rounded-xl p-3 border border-white/20">
                <div className="flex items-center gap-2 text-[#1A1A1A]/70 text-sm">
                  <User className="w-3.5 h-3.5" />
                  <span className="font-medium">Parent: {student.parent_name}</span>
                </div>
                <div className="flex items-center gap-2 text-[#1A1A1A]/70 text-sm">
                  <Phone className="w-3.5 h-3.5" />
                  <span className="font-mono">{student.parent_phone}</span>
                </div>
              </div>

              <div className="flex flex-col gap-2 mt-auto">
                <Button onClick={() => handleEdit(student)} variant="outline" className="w-full justify-center border-[#1A1A1A]/10 hover:bg-[#1A1A1A]/5 text-[#1A1A1A]">
                  <Edit className="w-4 h-4 mr-2" /> Edit Details
                </Button>
                <Button onClick={() => handleDelete(student)} variant="destructive" className="w-full justify-center bg-red-50 text-red-600 hover:bg-red-100 border border-red-100 shadow-none">
                  <Trash2 className="w-4 h-4 mr-2" /> Delete Record
                </Button>
              </div>
            </motion.div>
          ))}
          {students.length === 0 && (
            <div className="col-span-1 text-center py-10 text-[#1A1A1A]/50">
              <Users className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p>No students found. Add one above!</p>
            </div>
          )}
        </div>

        <AnimatePresence>
          {showModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto"
              onClick={() => setShowModal(false)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                className="bg-white/95 backdrop-blur-2xl rounded-2xl p-6 md:p-8 max-w-md w-full my-auto shadow-2xl border border-white/50 relative"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-extrabold text-[#1A1A1A] tracking-tight">
                    {editingStudent ? 'Edit' : 'Add New'} Student
                  </h2>
                  <Button variant="ghost" size="icon" className="text-[#1A1A1A]/50 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/5" onClick={() => setShowModal(false)}>
                    <X className="w-5 h-5" />
                  </Button>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="flex flex-col items-center gap-6 mb-6">
                    <div className="relative group">
                      <Avatar className="w-[120px] h-[120px] border-4 border-white shadow-lg">
                        <AvatarImage src={formData.photo_url} className="object-cover" />
                        <AvatarFallback className="bg-[#1A1A1A]/5 text-[#1A1A1A]/40 text-4xl">
                          <User className="h-16 w-16" />
                        </AvatarFallback>
                      </Avatar>
                      <div className="absolute inset-0 rounded-full bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                        {/* Overlay hover effect */}
                      </div>
                    </div>
                    
                    <div className="relative w-full max-w-xs text-center">
                      <input type="file" id="photo-upload" className="hidden" accept="image/*" onChange={handleFileUpload} disabled={uploading} />
                      <label 
                        htmlFor="photo-upload"
                        className={`inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-white border border-[#1A1A1A]/10 text-[#1A1A1A] rounded-full cursor-pointer text-sm font-semibold hover:bg-[#1A1A1A]/5 transition-all shadow-sm w-full ${uploading ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                        {uploading ? 'Uploading...' : 'Change Photo'}
                      </label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-[#1A1A1A]/60 uppercase tracking-wider ml-1">Full Name</label>
                    <input
                      placeholder="e.g. John Doe"
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      className="w-full p-3 bg-white/50 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] placeholder-[#1A1A1A]/30 focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 focus:bg-white transition-all"
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-[#1A1A1A]/60 uppercase tracking-wider ml-1">Standard</label>
                      <select
                        value={formData.standard}
                        onChange={e => setFormData({...formData, standard: e.target.value})}
                        className="w-full p-3 bg-white/50 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 focus:bg-white transition-all appearance-none"
                        required
                      >
                        <option value="" className="text-gray-400">Select</option>
                        {STANDARDS.map(s => <option key={s} value={s} className="text-[#1A1A1A]">{s}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-[#1A1A1A]/60 uppercase tracking-wider ml-1">Section</label>
                      <select
                        value={formData.class_section}
                        onChange={e => setFormData({...formData, class_section: e.target.value})}
                        className="w-full p-3 bg-white/50 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 focus:bg-white transition-all appearance-none"
                        required
                      >
                        <option value="" className="text-gray-400">Select</option>
                        {SECTIONS.map(s => <option key={s} value={s} className="text-[#1A1A1A]">{s}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-[#1A1A1A]/60 uppercase tracking-wider ml-1">Parent Name</label>
                    <input
                      placeholder="e.g. Jane Doe"
                      value={formData.parent_name}
                      onChange={e => setFormData({...formData, parent_name: e.target.value})}
                      className="w-full p-3 bg-white/50 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] placeholder-[#1A1A1A]/30 focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 focus:bg-white transition-all"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-[#1A1A1A]/60 uppercase tracking-wider ml-1">Phone Number</label>
                    <input
                      placeholder="e.g. +1 234 567 890"
                      value={formData.parent_phone}
                      onChange={e => setFormData({...formData, parent_phone: e.target.value})}
                      className="w-full p-3 bg-white/50 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] placeholder-[#1A1A1A]/30 focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 focus:bg-white transition-all"
                      required
                    />
                  </div>
                  
                  <Button type="submit" className="w-full bg-[#1A1A1A] text-white hover:bg-[#1A1A1A]/90 py-4 rounded-xl font-bold mt-4 shadow-lg h-auto text-lg">
                    {editingStudent ? 'Update Student Record' : 'Save New Student'}
                  </Button>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
};

export default StudentManagement;
