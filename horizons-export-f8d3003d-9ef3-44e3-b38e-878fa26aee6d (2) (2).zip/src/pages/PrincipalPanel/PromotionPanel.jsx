
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { TrendingUp, CheckCircle, XCircle, Trash2, GraduationCap, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAppContext } from '@/hooks/useAppContext';

const PromotionPanel = () => {
  const [selectedClass, setSelectedClass] = useState('');
  const { toast } = useToast();
  const { students, updateStudent, addPromotion, deleteStudent } = useAppContext();

  // Helper to safely parse standard to integer for comparison
  const getStandardNum = (std) => parseInt(std) || 0;

  const filteredStudents = selectedClass 
    ? students.filter(s => getStandardNum(s.standard) === parseInt(selectedClass))
    : students;

  const handlePromote = async (student) => {
    const currentClassNum = getStandardNum(student.standard);
    const newClassNum = currentClassNum + 1;
    
    if (newClassNum > 12) { 
      toast({ title: "Cannot Promote", description: "Student is already in the highest class", variant: "destructive" });
      return;
    }

    const newStandard = String(newClassNum);
    const { error: updateError } = await updateStudent(student.id, { standard: newStandard });
    
    if (updateError) {
      toast({ title: "Error", description: "Failed to update student record", variant: "destructive" });
      return;
    }

    await addPromotion({
      student_id: student.id,
      current_class: student.standard,
      status: 'promoted',
      new_class: newStandard,
      year: '2025-26'
    });

    toast({ title: "Student Promoted", description: `${student.name} promoted to Class ${newStandard}`, });
  };

  const handleRepeat = async (student) => {
    await addPromotion({
      student_id: student.id,
      current_class: student.standard,
      status: 'repeated',
      new_class: student.standard,
      year: '2025-26'
    });

    toast({ title: "Student Marked for Repeat", description: `${student.name} will repeat Class ${student.standard}`, variant: "destructive" });
  };

  const handleDelete = async (student) => {
    if (window.confirm(`Are you sure you want to delete ${student.name}?`)) {
      await deleteStudent(student.id);
      toast({ title: "Student Deleted", description: `${student.name} has been removed from records`, variant: "destructive" });
    }
  };

  const handleBulkPromote = async () => {
    if (!selectedClass) {
      toast({ title: "Select a Class", description: "Please select a class to promote", variant: "destructive" });
      return;
    }

    const classNum = parseInt(selectedClass);
    if (classNum >= 12) {
      toast({ title: "Cannot Promote", description: "Highest class students cannot be promoted further automatically", variant: "destructive" });
      return;
    }

    const studentsToPromote = students.filter(s => getStandardNum(s.standard) === classNum);
    
    if (studentsToPromote.length === 0) {
      toast({ title: "No Students", description: "No students found in this class to promote", variant: "default" });
      return;
    }

    let successCount = 0;
    for (const student of studentsToPromote) {
      const newStandard = String(classNum + 1);
      const { error } = await updateStudent(student.id, { standard: newStandard });
      
      if (!error) {
        await addPromotion({
          student_id: student.id,
          current_class: student.standard,
          status: 'promoted',
          new_class: newStandard,
          year: '2025-26'
        });
        successCount++;
      }
    }
    toast({ title: "Bulk Promotion Complete", description: `${successCount} students from Class ${classNum} promoted to Class ${classNum + 1}`, });
  };

  const classStats = selectedClass ? {
    total: filteredStudents.length,
    promoted: 0,
    repeated: 0,
    deleted: 0
  } : null;

  return (
    <>
      <Helmet>
        <title>Promotions - SchoolHub</title>
        <meta name="description" content="Manage student promotions and class transitions" />
      </Helmet>

      <div className="space-y-8 py-8 px-4 sm:px-0 pb-20 sm:pb-8">
        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#1A1A1A] mb-2 tracking-tight">
            Promotion Panel
          </h1>
          <p className="text-[#1A1A1A]/70 text-base sm:text-lg">Manage student promotions for the new academic year</p>
        </div>

        <div className="bg-white/40 backdrop-blur-xl rounded-2xl p-4 md:p-6 shadow-xl border border-white/50">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between mb-8">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full md:w-auto">
              <label className="text-[#1A1A1A] text-sm font-bold uppercase tracking-wider whitespace-nowrap">
                Select Class:
              </label>
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="w-full sm:w-auto px-4 py-3 sm:py-2 bg-white/60 border border-[#1A1A1A]/10 rounded-xl text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A1A1A]/10 font-medium text-base"
              >
                <option value="" className="text-gray-400">All Classes</option>
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(num => (
                  <option key={num} value={num} className="text-[#1A1A1A]">Class {num}</option>
                ))}
              </select>
            </div>

            <Button
              onClick={handleBulkPromote}
              disabled={!selectedClass}
              className="w-full md:w-auto bg-[#1A1A1A] hover:bg-[#1A1A1A]/90 text-white font-bold shadow-lg transition-all py-6 sm:py-4 h-auto"
            >
              <TrendingUp className="w-5 h-5 mr-2" />
              Bulk Promote Class {selectedClass || ''}
            </Button>
          </div>

          {classStats && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6 mb-8">
              <div className="bg-white/60 rounded-xl p-4 text-center border border-[#1A1A1A]/5 shadow-sm">
                <p className="text-[#1A1A1A]/60 text-xs font-bold uppercase">Total Students</p>
                <p className="text-[#1A1A1A] text-2xl font-extrabold">{classStats.total}</p>
              </div>
              <div className="bg-blue-50/50 rounded-xl p-4 text-center border border-blue-100 shadow-sm">
                <p className="text-blue-700 text-xs font-bold uppercase">To Be Promoted</p>
                <p className="text-blue-900 text-2xl font-extrabold">{classStats.total}</p>
              </div>
              <div className="bg-purple-50/50 rounded-xl p-4 text-center border border-purple-100 shadow-sm">
                <p className="text-purple-700 text-xs font-bold uppercase">Next Class</p>
                <p className="text-purple-900 text-2xl font-extrabold">{selectedClass ? parseInt(selectedClass) + 1 : '-'}</p>
              </div>
            </div>
          )}

          {/* Desktop Table View */}
          <div className="hidden md:block overflow-x-auto rounded-xl border border-[#1A1A1A]/5 bg-white/30">
            <table className="w-full min-w-[600px]">
              <thead>
                <tr className="border-b border-[#1A1A1A]/10 bg-white/40">
                  <th className="text-left text-[#1A1A1A]/60 font-bold py-3 px-4 uppercase text-xs tracking-wider">Name</th>
                  <th className="text-left text-[#1A1A1A]/60 font-bold py-3 px-4 uppercase text-xs tracking-wider">Current Class</th>
                  <th className="text-left text-[#1A1A1A]/60 font-bold py-3 px-4 uppercase text-xs tracking-wider">Section</th>
                  <th className="text-left text-[#1A1A1A]/60 font-bold py-3 px-4 uppercase text-xs tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1A1A]/5">
                {filteredStudents.map((student) => (
                  <motion.tr
                    key={student.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="hover:bg-white/50 transition-colors"
                  >
                    <td className="py-3 px-4 text-[#1A1A1A] font-semibold">{student.name}</td>
                    <td className="py-3 px-4 text-[#1A1A1A]/80 font-medium">Class {student.standard}</td>
                    <td className="py-3 px-4 text-[#1A1A1A]/80 font-medium">{student.class_section}</td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button onClick={() => handlePromote(student)} className="px-3 py-1 rounded-lg bg-green-100 text-green-700 hover:bg-green-200 transition-colors flex items-center justify-center gap-1 text-xs font-bold shadow-sm">
                          <CheckCircle className="w-3 h-3" /> Promote
                        </button>
                        <button onClick={() => handleRepeat(student)} className="px-3 py-1 rounded-lg bg-yellow-100 text-yellow-700 hover:bg-yellow-200 transition-colors flex items-center justify-center gap-1 text-xs font-bold shadow-sm">
                          <XCircle className="w-3 h-3" /> Repeat
                        </button>
                        <button onClick={() => handleDelete(student)} className="px-3 py-1 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition-colors flex items-center justify-center gap-1 text-xs font-bold shadow-sm">
                          <Trash2 className="w-3 h-3" /> Delete
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
                {filteredStudents.length === 0 && (
                  <tr>
                    <td colSpan="4" className="py-8 text-center text-[#1A1A1A]/50 font-medium">
                      No students found in this class.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Mobile Card View */}
          <div className="md:hidden grid grid-cols-1 gap-4">
            {filteredStudents.map((student) => (
              <motion.div
                key={student.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/60 rounded-xl p-5 border border-[#1A1A1A]/5 shadow-sm"
              >
                 <div className="flex justify-between items-start mb-4">
                   <div>
                     <h3 className="text-lg font-bold text-[#1A1A1A]">{student.name}</h3>
                     <p className="text-xs text-[#1A1A1A]/50 font-mono mt-1">ID: {student.id.slice(0, 8)}...</p>
                   </div>
                   <div className="text-right">
                     <span className="block text-sm font-bold text-[#1A1A1A]">Class {student.standard}</span>
                     <span className="block text-xs text-[#1A1A1A]/60">Sec {student.class_section}</span>
                   </div>
                 </div>

                 <div className="flex flex-col gap-2">
                    <button 
                      onClick={() => handlePromote(student)} 
                      className="w-full py-3 rounded-lg bg-green-100 text-green-700 font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-transform"
                    >
                      <CheckCircle className="w-4 h-4" /> Promote to Class {parseInt(student.standard) + 1}
                    </button>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <button 
                        onClick={() => handleRepeat(student)} 
                        className="py-3 rounded-lg bg-yellow-100 text-yellow-700 font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-transform"
                      >
                        <XCircle className="w-4 h-4" /> Repeat
                      </button>
                      <button 
                        onClick={() => handleDelete(student)} 
                        className="py-3 rounded-lg bg-red-100 text-red-700 font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-transform"
                      >
                        <Trash2 className="w-4 h-4" /> Delete
                      </button>
                    </div>
                 </div>
              </motion.div>
            ))}
             {filteredStudents.length === 0 && (
                <div className="text-center py-10 text-[#1A1A1A]/50 bg-white/30 rounded-xl border border-dashed border-[#1A1A1A]/10">
                  <GraduationCap className="w-12 h-12 mx-auto mb-3 opacity-20" />
                  <p>No students found for promotion.</p>
                </div>
              )}
          </div>

        </div>
      </div>
    </>
  );
};

export default PromotionPanel;
