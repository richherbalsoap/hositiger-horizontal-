
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/context/AuthContext';
import { AppProvider } from '@/context/AppContext';
import ProtectedRoute from '@/components/ProtectedRoute';
import MainLayout from '@/layouts/MainLayout';
import LoginPage from '@/pages/LoginPage';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import ResetPasswordPage from '@/pages/ResetPasswordPage';
import Dashboard from '@/pages/Dashboard';
import Settings from '@/pages/Settings';
import ComplaintsList from '@/pages/ComplaintsList';

// Teacher Tools
import HomeworkSender from '@/pages/TeacherPanel/HomeworkSender';
import ComplaintSender from '@/pages/TeacherPanel/ComplaintSender';
import ExamResultSender from '@/pages/TeacherPanel/ExamResultSender';
import FeesReminder from '@/pages/TeacherPanel/FeesReminder';

// Principal Tools
import StudentManagement from '@/pages/PrincipalPanel/StudentManagement';
import AnnouncementBot from '@/pages/PrincipalPanel/AnnouncementBot';
import Analytics from '@/pages/PrincipalPanel/Analytics';
import AIInsightChatbot from '@/pages/PrincipalPanel/AIInsightChatbot';
import PromotionPanel from '@/pages/PrincipalPanel/PromotionPanel';

import { Toaster } from '@/components/ui/toaster';

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppProvider>
          {/* Apply animated-bg class to a wrapper or body via index.css, 
              but since we need it for protected routes specifically, 
              MainLayout handles the main structure. 
              However, the user asked to apply it to the main app background in App.jsx.
              We'll wrap the protected routes or ensure MainLayout uses it.
              The index.css handles .animated-bg::before fixed positioning, 
              so we can apply it to the MainLayout root div.
          */}
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/reset-password" element={<ResetPasswordPage />} />
            
            <Route element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/complaints-list" element={<ComplaintsList />} />
              
              {/* Teacher Tools */}
              <Route path="/teacher-tools/homework" element={<HomeworkSender />} />
              <Route path="/teacher-tools/complaint" element={<ComplaintSender />} />
              <Route path="/teacher-tools/result" element={<ExamResultSender />} />
              <Route path="/teacher-tools/fees" element={<FeesReminder />} />
              
              {/* Principal Tools */}
              <Route path="/principal-tools/students" element={<StudentManagement />} />
              <Route path="/principal-tools/announcements" element={<AnnouncementBot />} />
              <Route path="/principal-tools/analytics" element={<Analytics />} />
              <Route path="/principal-tools/chatbot" element={<AIInsightChatbot />} />
              <Route path="/principal-tools/promotions" element={<PromotionPanel />} />
            </Route>

            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
          <Toaster />
        </AppProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
