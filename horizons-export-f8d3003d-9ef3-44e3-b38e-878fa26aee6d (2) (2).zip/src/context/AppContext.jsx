
import React, { createContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { 
  mockUsers, 
  mockStudents, 
  mockHomework, 
  mockComplaints, 
  mockResults, 
  mockAnnouncements 
} from '@/data/mockData';

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [students, setStudents] = useState([]);
  const [homework, setHomework] = useState([]);
  const [complaints, setComplaints] = useState([]);
  const [results, setResults] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [feesReminders, setFeesReminders] = useState([]);
  const [promotions, setPromotions] = useState([]);

  // Fetch data from Supabase on mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data: studentsData } = await supabase.from('students').select('*');
        if (studentsData) setStudents(studentsData);
        else setStudents(mockStudents);

        const { data: homeworkData } = await supabase.from('homework').select('*');
        if (homeworkData) setHomework(homeworkData);
        else setHomework(mockHomework);

        const { data: complaintsData } = await supabase.from('complaints').select('*');
        if (complaintsData) setComplaints(complaintsData);
        else setComplaints(mockComplaints);

        const { data: resultsData } = await supabase.from('results').select('*');
        if (resultsData) setResults(resultsData);
        else setResults(mockResults);

        const { data: announcementsData } = await supabase.from('announcements').select('*');
        if (announcementsData) setAnnouncements(announcementsData);
        else setAnnouncements(mockAnnouncements);
        
        const { data: feesData } = await supabase.from('fees_reminders').select('*');
        if (feesData) setFeesReminders(feesData);

        const { data: promotionsData } = await supabase.from('promotions').select('*');
        if (promotionsData) setPromotions(promotionsData);

      } catch (error) {
        console.error("Error fetching data:", error);
        // Fallback to mocks
        setStudents(mockStudents);
        setHomework(mockHomework);
        setComplaints(mockComplaints);
        setResults(mockResults);
        setAnnouncements(mockAnnouncements);
      }
    };

    fetchData();
  }, []);

  const refreshData = async (table) => {
    try {
      const { data } = await supabase.from(table).select('*');
      if (data) {
        switch(table) {
          case 'students': setStudents(data); break;
          case 'homework': setHomework(data); break;
          case 'complaints': setComplaints(data); break;
          case 'results': setResults(data); break;
          case 'announcements': setAnnouncements(data); break;
          case 'fees_reminders': setFeesReminders(data); break;
          case 'promotions': setPromotions(data); break;
        }
      }
    } catch (error) {
      console.error(`Error refreshing ${table}:`, error);
    }
  };

  const addStudent = async (student) => {
    const { error } = await supabase.from('students').insert([student]);
    if (!error) refreshData('students');
    return { error };
  };

  const updateStudent = async (id, updates) => {
    const { error } = await supabase.from('students').update(updates).eq('id', id);
    if (!error) refreshData('students');
    return { error };
  };

  const deleteStudent = async (id) => {
    const { error } = await supabase.from('students').delete().eq('id', id);
    if (!error) refreshData('students');
    return { error };
  };

  const addHomework = async (hw) => {
    const { error } = await supabase.from('homework').insert([hw]);
    if (!error) refreshData('homework');
    return { error };
  };

  const addComplaint = async (complaint) => {
    const { error } = await supabase.from('complaints').insert([complaint]);
    if (!error) refreshData('complaints');
    return { error };
  };

  const addResult = async (result) => {
    const { error } = await supabase.from('results').insert([result]);
    if (!error) refreshData('results');
    return { error };
  };

  const addAnnouncement = async (announcement) => {
    const { error } = await supabase.from('announcements').insert([announcement]);
    if (!error) refreshData('announcements');
    return { error };
  };

  const addFeesReminder = async (reminder) => {
    const { error } = await supabase.from('fees_reminders').insert([reminder]);
    if (!error) refreshData('fees_reminders');
    return { error };
  };

  const addPromotion = async (promotion) => {
    const { error } = await supabase.from('promotions').insert([promotion]);
    if (!error) refreshData('promotions');
    return { error };
  };

  const value = {
    students, homework, complaints, results, announcements, feesReminders, promotions,
    addStudent, updateStudent, deleteStudent,
    addHomework, addComplaint, addResult, addAnnouncement, addFeesReminder, addPromotion
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
