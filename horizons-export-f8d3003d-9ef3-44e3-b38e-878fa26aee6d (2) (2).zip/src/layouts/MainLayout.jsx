import React, { useState, memo, useCallback } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import { Toaster } from '@/components/ui/toaster';
import { Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import AnimatedBackground from '@/components/AnimatedBackground';
const MainLayout = memo(() => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const closeSidebar = useCallback(() => setIsSidebarOpen(false), []);
  const openSidebar = useCallback(() => setIsSidebarOpen(true), []);
  return <div className="min-h-screen flex font-sans text-white relative overflow-hidden">
      <AnimatedBackground />
      
      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen} onClose={closeSidebar} />
      
      <div className={cn("flex-1 flex flex-col min-h-screen transition-all duration-300 relative z-10", "lg:ml-72")}>
        {/* Mobile Header */}
        <div className="lg:hidden p-4 flex items-center border-b border-white/10 glass-panel-xl sticky top-0 z-30">
          <Button variant="ghost" size="icon" onClick={openSidebar} className="text-white mr-4 hover:bg-white/10 active:scale-95 transition-all">
            <Menu className="h-6 w-6" />
            <span className="sr-only">Toggle menu</span>
          </Button>
          <span className="font-bold text-white text-lg drop-shadow-[0_0_8px_rgba(6,182,212,0.5)]">AGENTRA Ai</span>
        </div>

        {/* Desktop Header */}
        <div className="hidden lg:block">
           <Header /> 
        </div>

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-8 mt-0 lg:mt-16 w-full max-w-full overflow-x-hidden relative z-10">
          <Outlet />
        </main>
      </div>
      <Toaster />
    </div>;
});
export default MainLayout;