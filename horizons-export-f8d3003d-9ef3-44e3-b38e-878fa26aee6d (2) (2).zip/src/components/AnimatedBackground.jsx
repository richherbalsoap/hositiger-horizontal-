
import React from 'react';

const AnimatedBackground = () => {
  return (
    <div 
      className="fixed inset-0 z-[-1] pointer-events-none"
      style={{
        background: 'linear-gradient(-45deg, #2e1065, #4c1d95, #d946ef, #06b6d4)',
        backgroundSize: '400% 400%',
        animation: 'gradient-wave 6s ease infinite'
      }}
    />
  );
};

export default AnimatedBackground;
