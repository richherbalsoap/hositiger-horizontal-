import React, { useState, useEffect, useCallback, memo } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Home, BookOpen, MessageSquare, Award, DollarSign, Bell, Users, BarChart3, Bot, TrendingUp, GraduationCap, Settings, ChevronRight, LogOut, X } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
const Sidebar = memo(({
  isOpen,
  onClose
}) => {
  const {
    logout
  } = useAuth();
  const location = useLocation();
  const [expandedGroups, setExpandedGroups] = useState({
    teacher: true,
    principal: true
  });
  useEffect(() => {
    if (window.innerWidth < 1024) {
      onClose && onClose();
    }
  }, [location.pathname, onClose]);
  const toggleGroup = useCallback(group => {
    setExpandedGroups(prev => ({
      ...prev,
      [group]: !prev[group]
    }));
  }, []);
  const teacherLinks = [{
    icon: BookOpen,
    label: 'Homework Sender',
    path: '/teacher-tools/homework'
  }, {
    icon: MessageSquare,
    label: 'Complaint Sender',
    path: '/teacher-tools/complaint'
  }, {
    icon: Award,
    label: 'Exam Result Sender',
    path: '/teacher-tools/result'
  }, {
    icon: DollarSign,
    label: 'Fees Reminder',
    path: '/teacher-tools/fees'
  }];
  const principalLinks = [{
    icon: Users,
    label: 'Student Management',
    path: '/principal-tools/students'
  }, {
    icon: Bell,
    label: 'Announcement Bot',
    path: '/principal-tools/announcements'
  }, {
    icon: BarChart3,
    label: 'Analytics',
    path: '/principal-tools/analytics'
  }, {
    icon: Bot,
    label: 'AI Insight Chatbot',
    path: '/principal-tools/chatbot'
  }, {
    icon: TrendingUp,
    label: 'Promotion Panel',
    path: '/principal-tools/promotions'
  }];
  const submenuVariants = {
    collapsed: {
      height: 0,
      opacity: 0,
      transition: {
        duration: 0.2,
        ease: "easeInOut"
      }
    },
    open: {
      height: "auto",
      opacity: 1,
      transition: {
        duration: 0.3,
        ease: "easeInOut"
      }
    }
  };
  const NavItem = ({
    item
  }) => <NavLink to={item.path} className={({
    isActive
  }) => cn("flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-300 group ml-3 mb-1 relative z-10", isActive ? "text-[#1A1A1A] bg-white/40 border-l-4 border-[#1A1A1A] font-semibold shadow-sm" : "text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-white/20")}>
      <item.icon className={cn("w-4 h-4 min-w-[1rem] transition-colors", ({
      isActive
    }) => isActive ? "text-[#1A1A1A]" : "text-[#1A1A1A]/70")} />
      <span className="text-sm truncate">{item.label}</span>
    </NavLink>;
  return <>
      <AnimatePresence>
        {isOpen && <motion.div initial={{
        opacity: 0
      }} animate={{
        opacity: 1
      }} exit={{
        opacity: 0
      }} onClick={onClose} className="lg:hidden fixed inset-0 bg-black/20 backdrop-blur-sm z-[999] cursor-pointer" />}
      </AnimatePresence>

      <div className={cn("w-full lg:w-72 h-screen border-r border-white/20 fixed left-0 top-0 overflow-y-auto flex flex-col transition-transform duration-300 ease-in-out z-[1000] bg-white/40 backdrop-blur-xl", isOpen ? "translate-x-0" : "-translate-x-full", "lg:translate-x-0")}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/40 border border-[#1A1A1A]/10 flex items-center justify-center shadow-sm">
                <GraduationCap className="w-6 h-6 text-[#1A1A1A]" />
              </div>
              <div>
                <h1 className="text-[#1A1A1A] font-bold text-lg">AGENTRA Ai</h1>
                <p className="text-[#1A1A1A]/60 text-xs font-medium">Admin Panel</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="lg:hidden text-[#1A1A1A]/70 hover:text-[#1A1A1A]" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          <nav className="space-y-6">
            <NavLink to="/dashboard" className={({
            isActive
          }) => cn("flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300", isActive ? "text-[#1A1A1A] bg-white/40 border-l-4 border-[#1A1A1A] font-semibold shadow-sm" : "text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-white/20")}>
              <Home className="w-5 h-5" />
              <span className="font-medium">Dashboard</span>
            </NavLink>

            {/* Teacher Tools */}
            <div>
              <button onClick={e => {
              e.stopPropagation();
              toggleGroup('teacher');
            }} className="flex items-center justify-between w-full px-4 py-2 text-[#1A1A1A]/80 hover:text-[#1A1A1A] transition-colors mb-2 group cursor-pointer">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4" />
                  <span className="font-semibold text-xs uppercase tracking-wider">Teacher Tools</span>
                </div>
                <ChevronRight className={cn("w-4 h-4 transition-transform duration-200", expandedGroups.teacher ? "rotate-90" : "rotate-0")} />
              </button>
              <AnimatePresence initial={false}>
                {expandedGroups.teacher && <motion.div key="teacher-group" variants={submenuVariants} initial="collapsed" animate="open" exit="collapsed" className="overflow-hidden">
                    {teacherLinks.map((link, idx) => <NavItem key={idx} item={link} />)}
                  </motion.div>}
              </AnimatePresence>
            </div>

            {/* Principal Tools */}
            <div>
              <button onClick={e => {
              e.stopPropagation();
              toggleGroup('principal');
            }} className="flex items-center justify-between w-full px-4 py-2 text-[#1A1A1A]/80 hover:text-[#1A1A1A] transition-colors mb-2 group cursor-pointer">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span className="font-semibold text-xs uppercase tracking-wider">Principal Tools</span>
                </div>
                <ChevronRight className={cn("w-4 h-4 transition-transform duration-200", expandedGroups.principal ? "rotate-90" : "rotate-0")} />
              </button>
              <AnimatePresence initial={false}>
                {expandedGroups.principal && <motion.div key="principal-group" variants={submenuVariants} initial="collapsed" animate="open" exit="collapsed" className="overflow-hidden">
                    {principalLinks.map((link, idx) => <NavItem key={idx} item={link} />)}
                  </motion.div>}
              </AnimatePresence>
            </div>
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-white/20 space-y-2 bg-white/20 backdrop-blur-xl">
          <NavLink to="/settings" className={({
          isActive
        }) => cn("flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300", isActive ? "text-[#1A1A1A] font-semibold" : "text-[#1A1A1A]/70 hover:text-[#1A1A1A]")}>
            <Settings className="w-5 h-5" />
            <span className="font-medium">Settings</span>
          </NavLink>
          
          <button onClick={logout} className="flex items-center gap-3 px-4 py-3 rounded-xl text-[#1A1A1A]/70 hover:text-[#1A1A1A] w-full transition-all duration-300 hover:bg-red-500/10 hover:text-red-600">
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </div>
    </>;
});
export default Sidebar;