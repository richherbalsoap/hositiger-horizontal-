
import React from 'react';
import { motion } from 'framer-motion';
import { LogOut, User, GraduationCap } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Header = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <motion.header
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="h-16 glass-panel-xl fixed top-0 right-0 left-72 z-30 hidden lg:block"
      style={{ borderBottomColor: 'rgba(255, 255, 255, 0.1)' }}
    >
      <div className="h-full px-8 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 rounded-lg bg-[#06b6d4] flex items-center justify-center shadow-[0_0_10px_rgba(6,182,212,0.6)]">
             <GraduationCap className="w-5 h-5 text-black" />
          </div>
          <div>
            <h2 className="text-sm text-white/60">Welcome back,</h2>
            <p className="font-semibold text-lg text-white drop-shadow-[0_0_8px_rgba(6,182,212,0.4)]">
              {user?.user_metadata?.name || user?.email?.split('@')[0] || 'Educator'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 px-4 py-2 rounded-xl bg-white/5 border border-white/10 hover:border-[#06b6d4] transition-colors">
            <div className="w-8 h-8 rounded-full bg-[#d946ef] flex items-center justify-center shadow-[0_0_10px_rgba(217,70,239,0.5)]">
              <User className="w-4 h-4 text-white" />
            </div>
            <div className="text-left">
              <p className="text-[#06b6d4] text-sm font-medium">{user?.email}</p>
            </div>
          </div>

          <Button
            onClick={handleLogout}
            className="bg-transparent border border-[#d946ef] text-[#d946ef] hover:bg-[#d946ef] hover:text-white hover:shadow-[0_0_15px_rgba(217,70,239,0.5)] transition-all"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;
