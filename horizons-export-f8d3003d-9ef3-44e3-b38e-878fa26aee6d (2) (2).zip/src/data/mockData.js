
export const mockUsers = [
  {
    id: 1,
    name: "Dr. Rajesh Kumar",
    email: "principal@school.com",
    role: "principal"
  }
];

export const mockStudents = [
  { id: 1, name: "Aarav Singh", standard: "1", class_section: "A", parent_phone: "+919876501001", parent_name: "Mr. Singh" },
  { id: 2, name: "Ananya Reddy", standard: "1", class_section: "B", parent_phone: "+919876501002", parent_name: "Mrs. Reddy" },
  { id: 3, name: "Vihaan Gupta", standard: "2", class_section: "A", parent_phone: "+919876502001", parent_name: "Mr. Gupta" },
  { id: 4, name: "Diya Mehta", standard: "3", class_section: "A", parent_phone: "+919876503001", parent_name: "Mrs. Mehta" }
];

export const mockHomework = [
  {
    id: 1,
    standard: "5",
    class_section: "A",
    subject: "Mathematics",
    notes: "Complete Chapter 3: Fractions",
    date: "2026-01-26"
  }
];

export const mockComplaints = [
  {
    id: 1,
    studentId: 1,
    standard: "1",
    class_section: "A",
    message: "Not paying attention in class.",
    date: "2026-01-25"
  }
];

export const mockResults = [
  {
    id: 1,
    studentId: 1,
    standard: "1",
    class_section: "A",
    subject: "Mathematics",
    marks: 85,
    total_marks: 100,
    date: "2026-01-20"
  }
];

export const mockAnnouncements = [
  {
    id: 1,
    message: "School closed on 26th Jan.",
    standard: "All",
    class_section: null,
    date: "2026-01-24"
  }
];
